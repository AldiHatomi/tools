#!/bin/bash
./sysadmin/web/conf/install.sh

apt update
apt install unzip apache2 mariadb-server mariadb-client php7.3 php7.3-cgi php7.3-cli  php7.3-common  php7.3-dba  php7.3-curl  php7.3-dba  php7.3-dev  php7.3-gd  php7.3-http  php7.3-imap  php7.3-intl  php7.3-json  php7.3-ldap  php7.3-lua  php7.3-mbstring php7.3-mcrypt php7.3-mysql-dbgsym php7.3-readline php7.3-soap php7.3-sqlite3 php7.3-uploadprogress php7.3-xml php7.3-zip libapache2-mod-php7.3 -y
apt update

wget https://download.nextcloud.com/server/releases/nextcloud-21.0.1.zip


clear

read -p "       Silahkan masukan lokasi directory cloud  => " lokasi;
echo '<VirtualHost *:80>' >> /etc/apache2/sites-available/nextcloud.conf
echo '    ServerAdmin admin@example.com' >> /etc/apache2/sites-available/nextcloud.conf
echo 'DocumentRoot '$lokasi >> /etc/apache2/sites-available/nextcloud.conf
echo '    ServerName nextcloud.example.com' >> /etc/apache2/sites-available/nextcloud.conf
echo '' >> /etc/apache2/sites-available/nextcloud.conf
echo '    Alias /cloud ''"'$lokasi'"' >> /etc/apache2/sites-available/nextcloud.conf
echo '' >> /etc/apache2/sites-available/nextcloud.conf
echo '    <Directory '$lokasi'>' >> /etc/apache2/sites-available/nextcloud.conf
echo '       Options +FollowSymlinks' >> /etc/apache2/sites-available/nextcloud.conf
echo '       AllowOverride All' >> /etc/apache2/sites-available/nextcloud.conf
echo '       Require all granted' >> /etc/apache2/sites-available/nextcloud.conf
echo '         <IfModule mod_dav.c>' >> /etc/apache2/sites-available/nextcloud.conf
echo '           Dav off' >> /etc/apache2/sites-available/nextcloud.conf
echo '         </IfModule>' >> /etc/apache2/sites-available/nextcloud.conf
echo '      SetEnv HOME '$lokasi >> /etc/apache2/sites-available/nextcloud.conf
echo '      SetEnv HTTP_HOME '$lokasi >> /etc/apache2/sites-available/nextcloud.conf
echo '    </Directory>' >> /etc/apache2/sites-available/nextcloud.conf
echo '' >> /etc/apache2/sites-available/nextcloud.conf
echo '    ErrorLog ${APACHE_LOG_DIR}/error.log' >> /etc/apache2/sites-available/nextcloud.conf
echo '    CustomLog ${APACHE_LOG_DIR}/access.log combined' >> /etc/apache2/sites-available/nextcloud.conf
echo '' >> /etc/apache2/sites-available/nextcloud.conf
echo '</VirtualHost>' >> /etc/apache2/sites-available/nextcloud.conf



unzip nextcloud-21.0.1.zip
mv nextcloud $lokasi


chown -R www-data:www-data $lokasi
chmod -R 755 $lokasi



a2ensite nextcloud.conf

/etc/init.d/apache2 restart


