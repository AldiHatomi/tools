#include <iostream>

using namespace std;

int main(){
    system("clear");
    system("./sysadmin/logo");

    int pilih;

    cout<<"         SILAHKAN PILIH OPSI YANG ANDA BUTUHKAN"<<'\n'<<'\n';
    cout<<"             1.  Install dan Konfigurasi"<<'\n';
    cout<<"             88. Menu Utama"<<'\n';
    cout<<"             00. Keluar"<<'\n'<<'\n'<<'\n';
    cout<<"         INPUTKAN OPSI YANG ANDA BUTUHKAN => ";
    cin>>pilih;

    if(pilih==1){
        system("clear");
        system("chmod 777 sysadmin/cloud/conf/cloud.sh");
        system("./sysadmin/cloud/conf/cloud.sh");
        system("./sysadmin/cloud/cloudd | lolcat");
    }

    else if(pilih==88){
        system("./tools.sh");
    }

    else if(pilih==00){

    }

    else{
        cout<<"     PILIHAN ANDA TIDAK DIKETAHUI";
    }
}

