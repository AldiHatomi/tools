#!/bin/bash


wget -q https://packages.sury.org/php/apt.gpg -o- 




echo 'deb [trusted=yes] https://packages.sury.org/php/ buster main' >> /etc/apt/sources.list


ls

apt update



apt install ca-certificates apt-transport-https wget curl unzip apache2 mariadb-server mariadb-client php7.3 php7.3-cgi php7.3-cli  php7.3-common  php7.3-dba  php7.3-curl  php7.3-dba  php7.3-dev  php7.3-gd  php7.3-http  php7.3-imap  php7.3-intl  php7.3-json  php7.3-ldap  php7.3-lua  php7.3-mbstring php7.3-mcrypt php7.3-mysql-dbgsym php7.3-readline php7.3-soap php7.3-sqlite3 php7.3-uploadprogress php7.3-xml php7.3-zip libapache2-mod-php7.3 -y
