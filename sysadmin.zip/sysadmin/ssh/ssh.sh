#!/bin/bash
chmod 777 sysadmin/ssh/sshh
./sysadmin/ssh/sshh | lolcat
