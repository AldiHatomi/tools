#include<iostream>
using namespace std;
int main(){
    system("clear");
    system("./logo");
    int pilih;
    cout<<"         SILAHKAN PILIH OPSI YANG ANDA BUTUHKAN"<<'\n'<<'\n';
    cout<<"             1.  Konfigurasi mail server "<<'\n';
    cout<<"             2.  Service Mail Server"<<'\n';
    cout<<"             3.  Status Mail Server"<<'\n';
    cout<<"             4.  Stop Mail Server"<<'\n';
    cout<<"             88. Menu Utama"<<'\n';
    cout<<"             00. Keluar"<<'\n'<<'\n'<<'\n';
    cout<<"         SILAHKAN MASUKAN PILIHAN ANDA => ";
    cin>>pilih;

    if(pilih==1){
        
    }
}