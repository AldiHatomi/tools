#!/bin/bash


read -p "     MASUKAN NUMBER PHONE    = " number;
read -p "     MASUKAN PASSWORD PHONE  = " pass;


echo '['$number']' >> /etc/asterisk/sip.conf
echo 'type=friend' >> /etc/asterisk/sip.conf
echo 'context=myphones' >> /etc/asterisk/sip.conf
echo 'secret='$pass >> /etc/asterisk/sip.conf
echo 'host=dynamic' >> /etc/asterisk/sip.conf




echo 'exten => '$number',1,Dial(SIP/'$number')' >> /etc/asterisk/extensions.conf
