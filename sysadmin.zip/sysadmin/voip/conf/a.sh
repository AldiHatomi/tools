#!/bin/bash


echo '[general]' >> /etc/asterisk/sip.conf
echo 'Port=5060' >> /etc/asterisk/sip.conf
echo 'bindaddr=0.0.0.0' >> /etc/asterisk/sip.conf
echo 'context=other' >> /etc/asterisk/sip.conf
echo '[other]' >> /etc/asterisk/extensions.conf
echo '[myphones]' >> /etc/asterisk/extensions.conf
