#include <iostream>

using namespace std;
int main(){
    system("clear");
    system("./sysadmin/logo");

    int pilih;

    cout<<"        INPUTKAN PILIHAN ANDA "<<'\n'<<'\n'<<'\n';
    cout<<"         1.  Install Asterisk"<<'\n';
    cout<<"         2.  Konfig Asterisk"<<'\n';
    cout<<"         3.  Restart Asterisk"<<'\n';
    cout<<"         4.  Asterisk status"<<'\n';
    cout<<"         5.  Asterisk status"<<'\n';
    cout<<"         88. Menu Utama"<<'\n';
    cout<<"         00. Keluar"<<'\n'<<'\n'<<'\n';
    cout<<"         INPUTKAN PILIHAN ANDA = ";
    cin>>pilih;

    if(pilih==1){
        system("apt install asterisk -y");
        system("chmod 777 sysadmin/voip/conf/a.sh");
        system("./sysadmin/voip/conf/a.sh");
        system("./sysadmin/voip/voipp | lolcat");
    }

    else if(pilih==2){
        system("chmod 777 sysadmin/voip/conf/voip.sh");
        system("./sysadmin/voip/conf/voip.sh | lolcat");
        
    }

    else if(pilih==3){
        system("/etc/init.d/astersk restart");
        system("./sysadmin/voip/voipp | lolcat");
        
    }

     else if(pilih==4){
        system("/etc/init.d/astersk status");
        
    }

     else if(pilih==5){
        system("/etc/init.d/astersk stop");
        system("./sysadmin/voip/voipp | lolcat");
        
    }

    else if(pilih==88){
        system("./tools.sh | lolcat");
        
    }

    else if(pilih==00){
        
    }


    else {
     cout<<"PILIHAN ANDA TIDAK DITEMUKAN..."<<'\n'<<'\n';
    }
}