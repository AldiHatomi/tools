#include <iostream>

using namespace std;

          int main(){
          system("clear");
          int pilih;


          system("chmod 777 sysadmin/logo");
          system("./sysadmin/logo");

          cout << "   1. Repository             6. DNS Server               11. Cloud Sever         00. Keluar"<<'\n';
          cout << "   2. Update                 7. WEB Server               12. Mail Server"<<'\n';
          cout << "   3. Upgrade                8. DHCP Server              13. VOIP Server"<<'\n';
          cout << "   4. SSH                    9. Firewall NAT             14. LoadBlace"<<'\n';
          cout << "   5. FTP Server            10. IP Config                15. RAPID"<<'\n'<<'\n'<<'\n';



          cout<<"Masukan pilihan anda = ";
          cin>>pilih;
          cout << ""<<'\n';
          cout << ""<<'\n';

                  if (pilih==1) {
                   system("chmod 777 sysadmin/repo/repo.sh");
                   system("chmod 777 sysadmin/repo/repo");
                   system("./sysadmin/repo/repo.sh");

                        }


                else if (pilih==2) {
                  cout<<"SEDANG MELAKUKAN UPDATE PACKAGE LIST REPOSITORY"<<'\n'<<'\n'<<'\n';
                   system("apt update");
                   system("clear");
                   system("./tools.sh");

                        }

                else if (pilih==3) {
                  cout<<"SEDANG MELAKUKAN UPGRADE PACKAGE LIST DARI REPOSITORY"<<'\n'<<'\n'<<'\n';
                   system("apt upgrade -y");
                   system("clear");
                   system("./tools.sh");

                        }

                else if (pilih==4) {
                   system("chmod 777 sysadmin/ssh/sshh.sh");
                   system("chmod 777 sysadmin/ssh/sshh");
                   system("./sysadmin/ssh/ssh.sh");
                 }



                else if (pilih==5) {
                   system("clear");
                   system("cd /root/Desktop/tools");
                   system("chmod 777 sysadmin/ftp/ftp.sh");
                   system("sh sysadmin/ftp/ftp.sh");
                }


                 else if (pilih==6) {
                   system("clear");
                   system("chmod 777 sysadmin/bind/con.sh");
          	       system("./sysadmin/bind/con.sh");

                }

                 else if (pilih==7) {
                   system("clear");
                 	 system("chmod 777 sysadmin/web/web");
                 	 system("./sysadmin/web/web | lolcat");
                }

                else if (pilih==8) {
                   system("chmod 777 sysadmin/dhcp/dhcpp");
                   system("./sysadmin/dhcp/dhcpp | lolcat");
                }

                else if(pilih==9){
                  int nat;
                    system("clear");
                    system("chmod 777 sysadmin/NAT/nat.sh");
                    system("./sysadmin/NAT/nat.sh");
                    system("./tools.sh");
                  
                }

                else if (pilih==10) {
                   system("chmod 777 sysadmin/ip/ip.sh");
                   system("./sysadmin/ip/ip.sh");
                }

                else if(pilih==11){
                   system("clear");
                   system("chmod 777 sysadmin/cloud/cloud");
                   system("./sysadmin/cloud/cloudd | lolcat");
                }

                else if(pilih==12){
                  system("chmod 777 sysadmin/loadblance/loadblance");
                  system("./sysadmin/loadblance/loadblance");
                }

                else if(pilih==13){
                  system("chmod 777 sysadmin/voip/voipp");
                  system("./sysadmin/voip/voipp | lolcat");
                }

                else if (pilih==0) {
                }

                else {
                  cout<<"PILIHAN ANDA TIDAK DITEMUKAN..."<<'\n'<<'\n';
                }
        }