#include <iostream>

using namespace std;

int main(){


    int pilihan;

    system("clear");
    system("./sysadmin/logo2");
    system("apt install net-tools");

    cout<<"         SILAHKAN PILIH OPSI YANG ANDA BUTUHKAN"<<'\n'<<'\n';
    cout<<"          1.  Config static"<<'\n';
    cout<<"          2.  Config DHCP"<<'\n';
    cout<<"          3.  Cek ip"<<'\n';
    cout<<"          00. Menu utama"<<'\n'<<'\n'<<'\n';

    cout<<"         SILAHKAN MASUKAN PILIHAN ANDA = ";
    cin>>pilihan;

        if(pilihan==1){
            system("chmod 777 sysadmin/ip/conf/static.sh");
            system("./sysadmin/ip/conf/static.sh");
            system("/etc/init.d/networking restart");
            system("./sysadmin/ip/ip.sh");
        }

        else if(pilihan==2){
            system("chmod 777 sysadmin/ip/conf/dhcp.sh");
            system("./sysadmin/ip/conf/dhcp.sh");
            system("/etc/init.d/networking restart");
            system("./sysadmin/ip/ip.sh");
        }

        
        else if(pilihan==3){
            system("ifconfig | lolcat");
        }

        else if(pilihan==00){
            system("./tools.sh");
        }

        else {
            cout<<"PILIHAN ANDA TIDAK DI KETAHUI";
        }

}