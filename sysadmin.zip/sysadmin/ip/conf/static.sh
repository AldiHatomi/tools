#!/bin/bash


read -p "       masukan nama interface anda = " int;
echo 'auto '$int >> /etc/network/interfaces
echo 'iface '$int' inet static'>> /etc/network/interfaces

read -p "       Masukan IP Address = " ip;
echo 'address '$ip >> /etc/network/interfaces

read -p "       Masukan IP Netmask = " nt;
echo 'netmask '$nt >> /etc/network/interfaces

read -p "       Masukan IP Gateway = " gt;
echo 'gateway '$gt >> /etc/network/interfaces
