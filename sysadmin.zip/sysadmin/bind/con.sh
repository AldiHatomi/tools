#!/bin/bash
chmod 777 sysadmin/bind/bindd
./sysadmin/bind/bindd | lolcat
